package com.example.criminalintent

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import com.example.criminalintent.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var bindingClass: ActivityMainBinding
    /*lateinit var n: CheckBox;*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        bindingClass = ActivityMainBinding.inflate((layoutInflater))
        setContentView(bindingClass.root)

        val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
        if(currentFragment == null){
            val fragment = CrimeFragment()
            supportFragmentManager
                .beginTransaction()
                .add(R.id.fragment_container, fragment)
                .commit()

            /*n = findViewById(R.id.crime_solved);*/
        }
    }

    fun goToNextPage(view: View) {
        val int = Intent(applicationContext, MainActivity2::class.java);
        startActivity(int);
    }
}