package com.example.criminalintent

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.view.View
import android.widget.TextView
import java.time.LocalDate
import java.time.LocalDateTime

class MainActivity2 : AppCompatActivity() {
    lateinit var textDate: TextView;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        val view: View = findViewById(R.id.some_view)
        textDate = findViewById(R.id.textDate);

        textDate.text = LocalDateTime.now().toString();

        val snackbar = Snackbar.make(view, "Хотите вернуться на прошлую страницу?",
            Snackbar.LENGTH_LONG)
        snackbar.setAction("Вернуться", View.OnClickListener {
            val int = Intent(applicationContext, MainActivity::class.java);
            startActivity(int);
        })

        snackbar.show()
    }


}